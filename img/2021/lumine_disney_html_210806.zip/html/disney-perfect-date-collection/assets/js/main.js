$(function () {
    fixtop = 60,
        $('a[href*=\\#]:not([href=\\#])').not('.inline').click(function () {
            if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
                var target = $(this.hash);
                target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                if (target.length) {
                    $('html,body').animate({
                        scrollTop: target.offset().top - fixtop
                    }, 1000);
                    return false;
                }
            }
        });
});

$(function () {
    $(".pagetop").hide();
    $(function () {
        $(window).scroll(function () {
            if ($(this).scrollTop() > 200) {
                $('.pagetop').fadeIn();
            } else {
                $('.pagetop').fadeOut();
            }
        });
    });
});


//inview
$(function () {
    if (!$("body").hasClass('top')) {
        $("body").addClass("fadeIn");
    }
});

$(function () {
    $('.inviewfadeIn').on('inview', function (event, isInView, visiblePartX, visiblePartY) {
        if (isInView) {
            $(this).stop().addClass('fadeIn');
        }
        // else {
        //     $(this).stop().removeClass('fadeIn');
        // }
    });

    // 上へスライド
    $('.inviewUp').on('inview', function (event, isInView, visiblePartX, visiblePartY) {
        if (isInView) {
            $(this).stop().addClass('Up');
        }
        // else {
        //     $(this).stop().removeClass('Up');
        // }
    });
    // フェードインしながら上へスライド
    $('.inviewfadeInUp').on('inview', function (event, isInView, visiblePartX, visiblePartY) {
        if (isInView) {
            $(this).stop().addClass('fadeInUp');
        }
        // else {
        //     $(this).stop().removeClass('fadeInUp');
        // }
    });
});


//Tab
$(function () {
    $(".p-tab__item").click(function () {
        var num = $(".p-tab__item").index(this);
        $(".p-goods__list-block").hide();
        $(".p-goods__list-block").eq(num).show();
        $(".p-tab__item").removeClass('active');
        $(this).addClass('active');
    });

});


//ilumine
$(function () {
    header = $('#header'),
        mv_bnr = $('.p-main-visual__i-lumine');

    $(window).on('scroll', function () {
        var value = $(this).scrollTop();
        if (value > header.height()) {
            mv_bnr.addClass('fixed');
        } else {
            mv_bnr.removeClass('fixed');
        }
    });
});


//モーダルウィンドウ
$(function () {
    var black = $('#js-back');
    var modal = $('#js-back .l-modal');
    $('#js-back').hide();
    $('#js-mv-btn').on('click', function () {
        $('#js-back').fadeIn('1500');
        black.animate({
            'opacity': '1',
        }, 1400);
        modal.delay(1400).animate({
            'opacity': '1',
        }, 800);
    });

    $('.close, #js-back').on('click', function () {
        $('#js-back').fadeOut('1500');
        return false;
    });
});


//メインビジュアル
$(function () {
    var $interval = 1500;
    var cnt = 0;
    var itemiList = ["", ".mv-item-last01 picture", ".mv-item-last02 picture", ".mv-item-last03 picture"];

    $(".mv-item-last01 picture, .mv-item-last02 picture, .mv-item-last03 picture").hide();
    $(window).on('load', function item() {
        if (cnt < itemiList.length) {
            $(itemiList[cnt]).fadeIn($interval).addClass("active");
            cnt++;
            setTimeout(function () {
                item();
            }, $interval);
        } else {
            return;
        }
    });
});
